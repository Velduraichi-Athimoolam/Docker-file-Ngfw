#! /bin/sh

service apache2 start &
python3 Proxy.py 